<grid filter="blur(30px)" drag="100 100" drop="0 0" class="fullImage">
![[Cover-PSLX.png]]
</grid>

<grid drag="100 10" class="header pslx steps has-light-background no-fragments" drop="topleft"  flow="row"  pad="0 40px">
[Johnny学](#home)

![[{{TOC}}]]
</grid>
<grid class="content" drag="100 80" drop="0 10" align="topleft" pad="20px 80px">
<% content %>
</grid>
<%? footnotes %>

