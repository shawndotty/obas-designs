<grid drag="100 100" drop="0 0" class="fullImage">
![[Cover-PSLX.png]]
</grid>
<grid drag="100 80" drop="0 10" class="content frontcover" align="center" pad="0 40px"  >
<% content %>
<grid drag="100 20" drop="0 65" align="center">
<%? author %>
</grid>
<grid drag="100 20" drop="0 70" align="center">
<%? date %>
</grid>
</grid>

