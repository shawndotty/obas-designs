<style>
.reveal .slides section .header.pslx {
  justify-content: space-between !important;
  align-items: center;
}

.reveal .slides section .header.pslx ul li {
  border-radius: 0;
}

.chapter-1 .header.pslx ul li:nth-child(1),
.chapter-2 .header.pslx ul li:nth-child(2),
.chapter-3 .header.pslx ul li:nth-child(3),
.chapter-4 .header.pslx ul li:nth-child(4),
.chapter-5 .header.pslx ul li:nth-child(5),
.chapter-6 .header.pslx ul li:nth-child(6),
.chapter-7 .header.pslx ul li:nth-child(7),
.chapter-8 .header.pslx ul li:nth-child(8),
.chapter-9 .header.pslx ul li:nth-child(9) {
  background-color: transparent;
  border-bottom: 4px solid var(--r-progress-background-color);
}

:root {
  --r-progress-text-color: var(--r-main-color);
  --r-list-background-color: #f8f8f8;
}

</style>