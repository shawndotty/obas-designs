<style>
.reveal .frontcover h1 {
margin-top: -200px;
}

.chapter-1 .header ul li:nth-child(1), .chapter-2 .header ul li:nth-child(2), .chapter-3 .header ul li:nth-child(3), .chapter-4 .header ul li:nth-child(4), .chapter-5 .header ul li:nth-child(5), .chapter-6 .header ul li:nth-child(6), .chapter-7 .header ul li:nth-child(7), .chapter-8 .header ul li:nth-child(8), .chapter-9 .header ul li:nth-child(9) {
background-color: transparent;
border-bottom: 2px solid var(--r-progress-background-color);
}

.reveal .slides section .header ul li {
border-radius: 0;
}
</style>