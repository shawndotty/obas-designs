<grid filter="blur(30px)" drag="100 100" drop="0 0" class="fullImage">
![[Content-GFSS.png]]
</grid>
<grid class="content" drag="90 90" drop="5 5" align="center">
<% content %>
</grid>


