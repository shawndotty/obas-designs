<grid drag="100 100" drop="0 0" class="fullImage">
![[Cover-GFSS.png]]
</grid>
<grid drag="100 80" drop="0 10" class="content frontcover" align="center" pad="0 40px"  >
<% content %>
<grid drag="100 10" drop="0 65">
<grid drag="15 100" drop="33 0" align="center" class="p-mb-0" justify-content="center" style="border-radius: 20px; border-bottom: 3px solid #333;"><%? author %></grid>
<grid drag="15 100" drop="52 0" align="center" class="p-mb-0" justify-content="center" style="border-radius: 20px; border-bottom: 3px solid #333;"><%? date %></grid>
</grid>
</grid>


