 <grid drag="100 100" drop="0 0" class="fullImage">
![[Back-GFSS.png]]
</grid>
<grid drag="40 70" drop="30 15" class="content backcover" align="center" pad="0 40px"  >
<% content %>
</grid>
![[Style-GFSS]]