<grid drag="100 100" drop="0 0" class="fullImage">
![[TOC-GFSS.png]]
</grid>

<grid class="content" drag="40 80" drop="30 10"   align="center"   style="z-index: 999;" justify-content="center">
<% content %>
</grid>